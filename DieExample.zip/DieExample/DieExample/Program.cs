﻿using System;

namespace DieExample
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Die nrml = new Die();
            Console.WriteLine("Die");
            Console.WriteLine("------");
            Console.WriteLine("No of sides:"+nrml.NumSide);
            Console.WriteLine("No of Topside:" + nrml.TopSide);

            Console.WriteLine("After roll");
            nrml.Roll();
            Console.WriteLine("No of Topside:" + nrml.TopSide);
            nrml.Roll();
            Console.WriteLine("No of Topside:" + nrml.TopSide);
            nrml.Roll();
            Console.WriteLine("No of Topside:" + nrml.TopSide);
            nrml.Roll();
            Console.WriteLine("No of Topside:" + nrml.TopSide);

            Console.WriteLine();
        }
    }
}
