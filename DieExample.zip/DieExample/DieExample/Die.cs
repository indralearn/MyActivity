﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DieExample
{
    internal class Die
    {
        #region Field
        int numSide;
        int topSide;
        Random rand = new Random();
        #endregion
        #region Constructor
        public Die()
        {
            numSide = 6;
            topSide = 1;
        }
        #endregion
        #region Property
        public int NumSide
        {
            get
            {
                return numSide;
            }
        }
        public int TopSide
        {
            get
            {
                return topSide;
            }
        }
        #endregion
        #region Method
        public void Roll()
        {
            Random rand = new Random();
            topSide = rand.Next(1, numSide + 1);
        }
        #endregion

    }
}
